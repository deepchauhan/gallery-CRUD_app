

const NotFound = () => {
    return (
        <h3>404 NOT FOUND</h3>
    )
}

export default NotFound;